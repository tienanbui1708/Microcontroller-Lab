/*
 * global.h
 *
 *  Created on: 17/09/26
 *      Author: TienAn
 */

#ifndef INC_GLOBAL_H_
#define INC_GLOBAL_H_

enum {TEST_BUTTON, TEST_LED7SEG};

#endif /* INC_GLOBAL_H_ */
