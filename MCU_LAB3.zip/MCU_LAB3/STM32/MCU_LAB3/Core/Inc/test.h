/*
 * test.h
 *
 *  Created on: 17/09/26
 *      Author: TienAn
 */

#ifndef INC_TEST_H_
#define INC_TEST_H_

void test_toggle_led_debug();
void test_button();
void test_led7seg();

#endif /* INC_TEST_H_ */
